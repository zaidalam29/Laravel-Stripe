<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stripe;
use session;

class CheckoutController extends Controller
{
    public function checkout()
    {   
        // Enter Your Stripe Secret
        \Stripe\Stripe::setApiKey('sk_test_51LJ4AYSGmZcoYtop1wmzBK5Lvli9sn3xg8XOcWQsin3fGBxHjNd6mhKng0SIyKlr2g4RRUntx2kz8YgZv7sIjq1300JGkNwj4q');

        		
		$amount = 100;
		$amount *= 100;
        $amount = (int) $amount;
        
        $payment_intent = \Stripe\PaymentIntent::create([
			'description' => 'Stripe Payment',
			'amount' => $amount,
			'currency' => 'INR',
			'description' => 'Stripe Laravel',
			'payment_method_types' => ['card'],
		]);
		$intent = $payment_intent->client_secret;

		return view('checkout.credit-card',compact('intent'));

    }

    public function afterPayment()
    {
        echo 'Payment Received, Thanks you for using our services.';
    }
}

